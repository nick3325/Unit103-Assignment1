let firstName = "Nicholas\n";
let lastName = "Lucien\n";
let email = "luciennick.bchs@gmail.com\n";
let password = "nugget\n";
let age = 23;
let country = " United States\n";
let catName = "Rico\n";
let dogName = "nuggett\n";
let carMake = "Nissan\n" 
let food = "Tacos\n";
let girlFriend = "Christina\n";
let neighbor = "Derrick\n";
let hobby = "Weight Lifting\n";
let sport = "Football\n";
let numofCars = 1;
let numofDogs = 1;
let favoriteFPlayer = "Tyreek Hill\n";
let favoriteBPlayer = " Kobe Bryant\n";
let favAlcohol = "Tequila\n";
let favCodingLang = "C++\n"




document.write(firstName);
document.write(lastName);
document.write(email);
document.write(password);
document.write(age);
document.write(country);
document.write(catName);
document.write(dogName);
document.write(carMake);
document.write(food);
document.write(girlFriend);
document.write(neighbor);
document.write(hobby);
document.write(sport);
document.write(numofCars);
document.write(numofDogs);
document.write(favoriteBPlayer);
document.write(favoriteFPlayer);
document.write(favAlcohol);
document.write(favCodingLang);
